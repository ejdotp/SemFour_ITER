package com.rasmi.ioc;

public class Voda implements Sim {
	@Override
	public void calling()
	{
		System.out.println("calling usin voda");
		
	}
	@Override
	public void data()
	{
		System.out.println("data vusing voda");
	}
}
