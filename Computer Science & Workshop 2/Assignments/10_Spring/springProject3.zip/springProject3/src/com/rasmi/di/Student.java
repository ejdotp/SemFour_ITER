package com.rasmi.di;

public class Student {
	
	private String studName;
	private int studId;
	public String getStudName() {
		return studName;
	}
	public void setStudName(String studName) {
		this.studName = studName;
	}
	public int getStudId() {
		return studId;
	}
	public void setStudId(int studId) {
		this.studId = studId;
	}
//	public Student(String studName, int studId)
//	{
//		this.studName=studName;
//		this.studId=studId;
//		
//	}
	
	

}
