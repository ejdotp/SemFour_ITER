public class scope{
    public static void main(String[] args) {
        int[] arr=new int[5];
        try{
            int k=100/0;
            System.out.println("inside try block");
        }
        catch(NullPointerException e){
            System.out.println("exception caught in catch");
        }
        finally{
            System.out.println("rest of code");
        }
    }
}