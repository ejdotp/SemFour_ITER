import java.util.PriorityQueue;

public class PQ {
 public static void main(String[] args) {
    // PriorityQueue<String>pq=new PriorityQueue<>();
    PriorityQueue<Integer>pq=new PriorityQueue<>();
    // pq.add(100);
    // pq.add(10);
    // pq.add(1000);
    // pq.add(10000);
    // pq.add(100000);
    // pq.add(1000000);
    // for(int i=0;i<3;i++){
    //     pq.add(i);
    //     pq.add(1);
    // }
    // pq.add("C");
    // pq.add("A");
    // pq.add("B");
    // pq.add("A");
    // pq.add("F");
    pq.add(2);
    pq.add(1);
    pq.add(5);
    pq.add(4);

    System.out.println(pq);
    // System.out.println(pq.peek());//only retrieves
    // System.out.println(pq.poll());//retrieves & remove
    // System.out.println(pq.peek());
    // System.out.println(pq.peek());//only retrieves
    // System.out.println(pq.poll());//retrieves & remove
    // System.out.println(pq.peek());
 }   
}
