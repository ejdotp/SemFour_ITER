import java.util.*;
public class HashTable {
    public static void main(String[] args) {
        
    }
}
