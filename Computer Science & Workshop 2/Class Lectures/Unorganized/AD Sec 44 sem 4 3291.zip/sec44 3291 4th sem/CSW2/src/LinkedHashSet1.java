import java.util.*;
public class LinkedHashSet1 {
    public static void main(String[] args) {
        LinkedHashSet <String> set=new LinkedHashSet<>();
        set.add("Rahul");
        set.add("Suman");
        set.add("Baal light");
        set.add("Namuna");
        Iterator<String> i=set.iterator();
        while(i.hasNext()){
            System.out.println(i.next());
        }
        System.out.println(set);
    }
}
