//create a class of person with private variables Name,Age
class Person 
{
	private String Name;
	private int age;
	public String getName()
	{
		return Name;
	}
	public void setName(String Name)
	{
		this.Name=Name;
	}
	public int getAge()
	{
		return age;
	}
	public void setAge(int age)
	{
		this.age=age;
	}
}


public class Encapsulation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person obj=new Person();
		obj.setName("Rahul");
		obj.setAge(20);
		System.out.println(obj.getName());
		System.out.println(obj.getAge());
	}

}
