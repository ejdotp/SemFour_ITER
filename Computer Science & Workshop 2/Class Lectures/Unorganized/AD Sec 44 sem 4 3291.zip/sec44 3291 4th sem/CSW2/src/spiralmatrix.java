public class spiralmatrix {
   
}
