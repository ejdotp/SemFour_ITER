import java.util.ArrayList;
import java.util.List;

public class nongeneric {
    public static void main(String[] args) {
        List<Integer> list=new ArrayList<>();
        // list.add("cc");
        list.add(20);
        int n=(Integer)list.get(0);
        System.out.println(n);
    }
}
