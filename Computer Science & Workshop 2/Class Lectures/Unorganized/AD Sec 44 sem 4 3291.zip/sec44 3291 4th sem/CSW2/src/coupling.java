class A{
	private String Name;
	public String getname() {
		if(Name!=null) {
			return Name;
		}
		else {
			return "Not Initialized!!";
		}
	}
	public void setname(String Name) {
		if(Name==null) {
			System.out.println("Can't Initialize to null");
		}
		else {
			this.Name=Name;
		}
	}
	
}
public class coupling {
    public static void main(String[] args) {
        A a=new A();
        a.setname("Baal light");
        System.out.println("Name is "+a.getname());
    }
}
