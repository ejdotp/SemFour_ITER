import java.util.*;
import java.io.*;
public class file_handling_write {
    public static void main(String[] args) {
        try{
            FileWriter Write=new FileWriter("myfile.txt");
            Write.write("Hello,I have written somethoing for you");
            Write.close();
            System.out.println("Successfully written");
        }
        catch(IOException e){
            System.out.println("Error");
        }

    }
}
