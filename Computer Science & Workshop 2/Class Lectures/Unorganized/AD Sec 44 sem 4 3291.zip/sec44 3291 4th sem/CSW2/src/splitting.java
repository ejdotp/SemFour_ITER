public class splitting {
    public static void main(String[] args) {
        String s="ITER:A SOA UNIVERSITY";
        String []piece=s.split(":");
        for(String a: piece){
            System.out.println(a);
        }
        String name="Subham Mohanty";
        String []p=name.split("a");
        
        for(String a: p){
            System.out.println(a);
        }
        
        String x="Subh&am@Moh*anty*U@d:i:p&t&a";
        String []y=x.split("[*&:@]");
        for(String a: y){
            System.out.println(a);
        }
        String z="I@Miss@You@So@Much@@";
        String z1[]=z.split("@",-2);
        for(String a: z1){
            System.out.println(a);
        }
        String z2[]=z.split("@",0);
        for(String a: z2){
            System.out.println(a);
        }
        StringBuffer s1=new StringBuffer("Hello");
        s1=s1.append("You");
        System.out.println(s1);
        StringBuilder s2=new StringBuilder("Hello");
        s2=s2.append("You");
        System.out.println(s2);


    }
}
