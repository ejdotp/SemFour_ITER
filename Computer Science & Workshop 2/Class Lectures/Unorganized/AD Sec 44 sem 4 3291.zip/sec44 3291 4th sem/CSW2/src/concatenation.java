public class concatenation {
    public static void main(String[] args) {
        //method 1(a):
        String s1="Hello";
        String s2=" Baal light";
        System.out.println(s1+s2);
        //method 1(b)
        String s3=" Rahul is a";
        String s4=" Late Processor just like ";
        int s5=8086;
        String s6=s3+s4+s5;
        s6=s1+s2+s3+s4+s5;
        System.out.println(s6);
        //method 2
        String x1="Hey";
        x1=x1.concat(" Ma'am");
        System.out.println(x1);

        String x2=" Ma'am";
        x1=x1.concat(x2);
        System.out.println(x1);

        String x3=x1.concat(x2);
        System.out.println(x3);

        //different datatype argument in concat() gives error
        // s1=s1.concat(s5);
        // System.out.println(s1); Error!!!!!!!!!!
        s1=s1.concat(s2);
        System.out.println(s1);//no error

        //nullpointer exception
        String a=null;
        String b=" hey";
        // b=b.concat(a);
        // System.out.println(b); Error!!!!!!
        s6=a+b;
        System.out.println(s6);

        //+ OPERATOR ALWAYS MAKES A NEW STRING

        // case1
        System.out.println("case1:");
        String p="hello";
        String q="";
        String r=p.concat(q);
        if(p==r){
            System.out.println("same");
        }
        else{
            System.out.println("different");
        }
        String s=p+q;
        if(p==s){
            System.out.println("same");
        }
        else{
            System.out.println("different");
        }
    }
}
