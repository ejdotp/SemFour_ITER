import java.util.*;
public class LL {
    public static void main(String[] args) {
        LinkedList<String>ll=new LinkedList<>();
        ll.add("NRI");
        ll.add("Biradi Baishnava");
        ll.add("Late Processor");
        ll.add("Baal light");
        Iterator<String> itr=ll.iterator();     
        while(itr.hasNext()){
            System.out.println(itr.next());                                                                                                                                                                                  
    }
  }
}
