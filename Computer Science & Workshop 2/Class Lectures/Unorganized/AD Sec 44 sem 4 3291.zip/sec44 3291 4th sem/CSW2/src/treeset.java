import java.util.*;
public class treeset {
    public static void main(String[] args) {
        TreeSet<String> tr=new TreeSet<>();
        tr.add("Namuna");
        tr.add("ChotaChua");
        tr.add("late processor");
        tr.add("Biradi Baishnav");
        tr.add("CopyCat");
        tr.add("Baal light");
        TreeSet<Integer> tr1=new TreeSet<>();
        tr1.add(1);
        tr1.add(1111);
        tr1.add(111);
        tr1.add(11);
        tr1.add(11111);
        tr1.add(111111);
        Iterator<String>itr=tr.iterator();
        while(itr.hasNext()){
            System.out.println(itr.next());
        }
        System.out.println(tr);
        Iterator i=tr1.descendingIterator();1
        while(i.hasNext()){
            System.out.println(i.next());
        }
        System.out.println(tr1);
        //pollfirst pops the element
        System.out.println("lowest value:"+tr1.pollFirst());
        System.out.println("Highest value:"+tr1.pollLast());
        System.out.println("lowest value:"+tr.pollFirst());
        System.out.println("Highest value:"+tr.pollLast());
        System.out.println( tr.subSet("Baal light", "CopyCat"));
        System.out.println( tr1.subSet(1, 11111));
        System.out.println( tr1.tailSet(111));
        System.out.println( tr1.headSet(11));
        System.out.println( tr1.descendingSet());
        System.out.println( tr1);

    }
}
