class Employee {

    private int ID;

    private int age;

    private String name;

    private static int nextId = 1;

    public Employee(String name, int age) {

        this.name = name;

        this.age = age;

        this.ID = nextId++;

    }

    public void show() {

        System.out.println(ID + " " + name + " " + age);

    }

    public void showNextId() {

        System.out.println(nextId);

    }

}

public class garbagecollection {

    public static void main(String[] args) {

        Employee E = new Employee("", 20);

        E.show();

        E.showNextId();

        Employee F = new Employee("BAAL LIGHT", 20);

        F.show();

        F.showNextId();

        Employee G = new Employee("CHANGACHANGIA", 21);

        G.show();

        G.showNextId();

        {

            Employee X = new Employee("RAHUL", 21);

            Employee Y = new Employee("ATPIDU", 20);

            X.show();

            Y.show();

            X.showNextId();

            Y.showNextId();

        }

        E.showNextId();

    }

}
