import java.util.LinkedList;

public class LL2 {
    public static void main(String[] args) {
        LinkedList<String> ll=new LinkedList<>();
        System.out.println("Initial list of elements:"+ll);
        ll.add("Rahul");
        ll.add("EJ");
        ll.add("Ghanchu");
        System.out.println("After invoking add method:"+ll);
        //at specific position
        ll.add(1, "inkdropinwater");
        System.out.println("After invoking add index method:"+ll);
        LinkedList<String> ll2=new LinkedList<>();
        ll2.add("ME");
        ll2.add("Krishna");
        ll2.add("Mohan");
        ll.addAll(ll2);
        System.out.println("after invoking addAll:"+ll);
        LinkedList<String> ll3=new LinkedList<>();
        ll3.add("Suman");
        ll3.add("Namuna");
        ll.addAll(1, ll3);
        System.out.println("After invokind addAll with index:"+ll);
        ll.addFirst("ATPIDU");
        ll.addLast("MAHBUS");
        System.out.println("FINAL LIST:"+ll);
        ll.remove("ME");
        System.out.println("After remove:"+ll);
        ll.remove(4);
        System.out.println("after removing index:"+ll);
        ll.removeFirstOccurrence("Suman");
        ll.removeAll(ll3);
        System.out.println("after removing ll3:"+ll);
        ll.removeFirst();
        ll.removeLast();
        System.out.println("Removing 1st & last:"+ll);
        ll.removeAll(ll2);
        System.out.println("removing all ll2:"+ll);
    }
}
