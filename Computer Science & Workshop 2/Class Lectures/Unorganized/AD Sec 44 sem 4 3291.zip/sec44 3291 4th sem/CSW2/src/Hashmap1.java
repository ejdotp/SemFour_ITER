import java.util.*;
public class Hashmap1 {
    public static void main(String[] args) {
        HashMap<Integer,String> map=new HashMap<>();
        HashMap<Integer,String> map1=new HashMap<>();
        map.put(1,"Mango");
        map.put(2,"Apple");
        map.put(4,"Grapes");
        map.put(3,"Banana");
        map.putIfAbsent(4, "Pijuli");//wont work
        map.putIfAbsent(5, "Pijuli");//wont work
        map.putIfAbsent(6, "Apple");//will work
        map1.put(7, "Tomato");
        map1.putAll(map);
        map1.remove(4);
        map1.remove(6,"Apple");//value is not relevant in this function
        map1.replaceAll((k,v)->"Baal light");//all values become Baal light
        System.out.println("Iterating HashMap....");
        for(Map.Entry m : map1.entrySet()){
            System.out.println(m.getKey()+" "+m.getValue());
        }
    }
}
