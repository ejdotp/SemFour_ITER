public class scope2 {
    public static void main(String[] args) {
        try{
            String str="123a";
            int num=Integer.parseInt(str);
            System.out.println("Inside try block");
        }
        catch(NumberFormatException e){
            System.out.println("catch it");
        }
        System.out.println("outside try-catch clause");
    }
}
