class SpiralMatrix{
    public static void main(String[] args) {
        int arr[][]={{1,2,3,4,5},{6,7,8,9,10},{11,12,13,14,15},{16,17,18,19,20},{21,22,23,24,25}};
        int s[]=new int[25];
        int m=0;
        int j=0;
        int l=0;
        int p=0;
        int y=5;
        for(int i=0;i<Math.ceil(y/2);i++){
            //Forward
            for(j=i;j<5-1;j++){
                s[m]=arr[i][j];
                m++;
               
            }
            //Downward
            for(int k=i;k<y-1;k++){
                s[m]=arr[k][j];
                m++;
            }
            //Backward
            for(l=y-1;l>i;l--){
                s[m]=arr[j][l];
                m++;
            }
            //Upward
            for(p=y-1;p>i;p--){
                s[m]=arr[p][l];
                m++;
            }
            y--;
            for(int q=0;q<25;q++){
                System.out.print(s[q]+" ");
            }
        }
       
       
    }
}

