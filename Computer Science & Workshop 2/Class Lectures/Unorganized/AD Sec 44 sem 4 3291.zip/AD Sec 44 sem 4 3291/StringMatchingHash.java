public class StringMatchingHash {
    public static int Robinkarp(String text1,String pattern1){
        char[]text=text1.toCharArray();
        char[]pattern=pattern1.toCharArray();
        int n=text1.length();
        int m=pattern1.length();
        int i,j;
        int prime=101; //module
        int powm=1;//base
        int texthash=0,patternhash=0;
        if(m==0||m>n)
        {
            return -1;
        }
        for(i=0;i<m-1;i++)
        {
            powm=(powm<<1)%prime;
        }
        for(i=0;i<m;i++){
            patternhash=((patternhash<<1)+pattern[i])%prime;
            texthash=((texthash<<1)+text[i])%prime;
        }
        for(i=0;i<(n-m);i++)
        {
            if(texthash==patternhash);
            for(j=0;j<m;j++)
            {
                if(text[i+j]!=pattern[j])
                break;
            }
            if(j==m){
                return i;
            }
            if(i<n-m){
                texthash=(((texthash-text[i]*powm)<<1)+text[i+m])%prime;
            }
            if(texthash<0)
            {
                texthash=texthash+prime;
            }
        }
        return -1;
    }
    public static void main(String[] args) {
        String text = "I'm Luffy, the man who's gonna be the king of the pirates.";
        // word that want to be matched in the text
        String pattern = "who's";
        System.out.println("Present in index:"+Robinkarp(text, pattern));
    }
}
