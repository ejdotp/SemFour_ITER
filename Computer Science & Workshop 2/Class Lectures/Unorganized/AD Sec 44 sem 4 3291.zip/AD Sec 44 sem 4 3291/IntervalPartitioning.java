import java.util.*;

class Intervals {

 int start;

 int end;

 public Intervals(int start, int end) {

 this.start = start;

 this.end = end;

 }

}



public class IntervalPartitioning{

	

 public static int partitionIntervals(List<Intervals> intervals) {

 Collections.sort(intervals, Comparator.comparingInt(a -> a.start)); //sorted according to start time

 PriorityQueue<Integer> endTimes = new PriorityQueue<>();

 int partitions = 0;

 for (Intervals interval : intervals) {

 if (!endTimes.isEmpty() && interval.start >= endTimes.peek()) {

 endTimes.poll();

 }

 else {

 partitions++;

 }

 endTimes.offer(interval.end);

 }

 return partitions;

 }



 public static void main(String[] args) {

 List<Intervals> in = new ArrayList<>();

 in.add(new Intervals(1,3));

 in.add(new Intervals(2,5));

 in.add(new Intervals(3,6));

 in.add(new Intervals(5,7));

 in.add(new Intervals(6,9));

 System.out.println("Minimum no. of classrooms:"+partitionIntervals(in));
 }
}