import java.util.*;

public class ropecost {
    public static int mincost(int l[]){
        Arrays.sort(l);
        int min=0,cost=0;
        for(int i=0;i<l.length;i++)
        {
           cost+=l[i];
           for(int j=i+1;j<l.length;j++){
            if(cost<=l[j]){
                min=l[j];
            }
           }
        }
        return min;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the total ropes:");
        int N=sc.nextInt();
        System.out.println("Enter lengths:");
        int l[]=new int[N];
        for(int i=0;i<N;i++){
            l[i]=sc.nextInt();
        }
        System.out.println("Rope min cost:"+mincost(l));
    }
}
