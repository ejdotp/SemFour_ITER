class StringMatchingBruteForce {
    public int bruteforce(String text, String tobematched) {
        int n = text.length();// length of the text
        int m = tobematched.length();// length of the pattern;

        for (int i = 0; i < n; i++) {
            int j = 0;
            while ((j < m) && (text.charAt(i + j) == tobematched.charAt(j))) {
                j++;
            }
            if (j == m) {
                return i;
            }
        }

        return -1;
    }

    public static void main(String[] args) {
        StringMatchingBruteForce obj = new StringMatchingBruteForce();
        // text
        String text = "I'm Luffy, the man who's gonna be the king of the pirates.";
        // word that want to be matched in the text
        String tobematched = "who's";
        int position = obj.bruteforce(text, tobematched);
        if (position == -1) {
            System.out.println("Pattern is not matched in the text");
        } else {
            System.out.println("Found at position:" + (position));
            System.out.println("End at the position:" + (position + tobematched.length()));
        }
    }
}
