package com.Section44.SpringlearnJagadeeswar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringLearnJagadeeswarApplicationTests {

	@Test
	void contextLoads() {
	}

}
