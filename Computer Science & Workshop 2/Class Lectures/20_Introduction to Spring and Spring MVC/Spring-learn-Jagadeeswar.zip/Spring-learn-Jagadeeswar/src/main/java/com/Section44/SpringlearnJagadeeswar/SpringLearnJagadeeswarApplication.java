package com.Section44.SpringlearnJagadeeswar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringLearnJagadeeswarApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringLearnJagadeeswarApplication.class, args);
	}

}
